from  django.conf.urls import url
from registration import views
urlpatterns = [
    url('^$',views.registr,name='registr'),
   url('^viewregisteredusers/',views.viewregisteredusers,name='viewregisteredusers'),
url('^viewregisteredusersandchit/',views.viewregisteredusersandchit,name='viewregisteredusersandchit'),
    ]