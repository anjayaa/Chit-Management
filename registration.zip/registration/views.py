from django.shortcuts import render
from registration.models import Registration
# Create your views here.
def registr(request):
    if request.method == "POST":
        obj = Registration()
        # ob = Login()
        # sid = Staff.objects.all().aggregate(Max('sid'))
        # sidd = list(sid.values())[0]
        # siddv = ''
        #
        # # for character assigied auto inctement id generttion
        # # if not (sidd is None):
        # #   siddv="m"+str(sidd+1)
        # # else:
        # #     siddv="m1"
        # #     sidd=0
        #
        # obj.sid = sidd + 1
        # dt = datetime.date.today()  # Returns 2018-01-15

        obj.name = request.POST.get("Name")
        obj.address = request.POST.get("Add")

        obj.gender = request.POST.get("Gender")
        obj.occupation = request.POST.get("Occup")
        obj.accountnumber = request.POST.get("accno")
        obj.nomineename = request.POST.get("nName")
        obj.relationship= request.POST.get("relation")

        obj.naddress = request.POST.get("add")
        obj.mobilenumber = request.POST.get("number")
        obj.email = request.POST.get("email")
        obj.ifsccode = request.POST.get("ifsc")
        obj.aadharnumber = request.POST.get("aadhar")


        obj.save()

    return render(request,'registration/registr.html')
def viewregisteredusers(request):

    #objlist = Complaint.objects.all()
    objlist=Registration.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request,'registration/view registerd users.html',context)
