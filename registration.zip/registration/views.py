from django.shortcuts import render
from registration.models import Registration
from login.models import Login
from django.db.models import Max
from django.db import connection
# Create your views here.
def registr(request):
    if request.method == "POST":
        obj = Registration()
        ob = Login()
        sid = Registration.objects.all().aggregate(Max('u_id'))
        sidd = list(sid.values())[0]
        siddv = ''

        # for character assigied auto inctement id generttion
        # if not (sidd is None):
        #   siddv="m"+str(sidd+1)
        # else:
        #     siddv="m1"
        #     sidd=0

        obj.u_id = sidd + 1
        ob.uid = sidd + 1
        ob.username = request.POST.get("email")
        ob.password = request.POST.get("password")
        ob.type = "user"
        ob.save()


        obj.name = request.POST.get("Name")
        obj.address = request.POST.get("Add")

        obj.gender = request.POST.get("Gender")
        obj.occupation = request.POST.get("Occup")
        obj.accountnumber = request.POST.get("accno")
        obj.nomineename = request.POST.get("nName")
        obj.relationship= request.POST.get("relation")

        obj.naddress = request.POST.get("add")
        obj.mobilenumber = request.POST.get("number")
        obj.email = request.POST.get("email")
        obj.ifsccode = request.POST.get("ifsc")
        obj.aadharnumber = request.POST.get("aadhar")


        obj.save()

    return render(request,'registration/registr.html')
def viewregisteredusers(request):

    objlist=Registration.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request,'registration/view registerd users.html',context)
def viewregisteredusersandchit(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM chitdetails a,registration b, request c WHERE a.c_id=c.c_id AND b.u_id=c.u_id and c.status='approve'")



    context = {
        'objval': objlist.fetchall(),
    }


    return render(request,'registration/view reguser and chit.html',context)
