from django.shortcuts import render
from verification.models import Verification
from django.db import connection
# Create your views here.
def verification(request):
    if request.method == "POST":
        obj = Verification()
        obj.m_id=request.session["user"]
        obj. document_type = request.POST.get("docs")
        obj.documents = request.POST.get("ddocs")
        obj.status = "verified"
        obj.save()
    return render(request,'verification/verification.html')
def viewverification(request):
    # execute = connection.cursor()
    # objlist = execute("SELECT * FROM chitdetails a,registration b, resultdetails c WHERE a.c_id=c.amount=amount AND b.u_id=c.u_id and c.amount='amount'")
    # context = {
    #     'objval': objlist.fetchall(),
    # }
    # objlist = connection.cursor()
    objlist = connection.cursor()
    objlist.execute(
        "SELECT * FROM chitdetails a,registration b, resultdetails c WHERE b.u_id=c.u_id AND a.c_id=c.c_id ")

    context = {
        'objval': objlist.fetchall(),
    }

    return render(request,'verification/view verifiedusers.html',context)