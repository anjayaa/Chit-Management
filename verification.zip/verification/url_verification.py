from  django.conf.urls import url
from verification import views
urlpatterns = [
    url('^$',views.verification,name='verification'),
   url('^viewverification/',views.viewverification,name='viewverification'),

]
