from django.shortcuts import render
from complaint.models import Complaint
from registration.models import Registration
from request.models import Request
from django.db import connection
import datetime

# Create your views here.
def complaint(request):
    # objlist = Request.objects.filter(status='approve',u_id=request.session["user"])
    # context = {
    #     'objval': objlist,
    # }
    # uid=request.session["user"]
    uid=request.session["user"]

    objlist = connection.cursor()
    uidd=str(uid)
    query=("SELECT * FROM chitdetails a,request b WHERE a.c_id=b.c_id and b.u_id=%s")
    objlist.execute(query, [uid])
    # print(uid)
    # print(uidd)

    context = {
        'objval': objlist.fetchall(),
        # 'msg':uidd,
    }

    if request.method == "POST":
        obj = Complaint()

        obj.description = request.POST.get("Add")
        obj.u_id = request.session["user"]
        obj.c_id =request.POST.get("cname")
        obj.date = datetime.date.today()
        obj.replay = "pending"
        obj.save()
    return render(request,'complaint/comlaint.html',context)

def replycomplaint(request,idd):
    objlist = Complaint.objects.get(comp_id=idd)
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Complaint.objects.get(comp_id=idd)
        obj.replay = request.POST.get("reply")
        obj.save()
        return viewcomplaint(request)
    else:
         return render(request,'complaint/replycomplaint.html',context)

def viewcomplaint(request):
    objlist = Complaint.objects.filter(replay='pending')
    context = {
        'objval': objlist,
    }
    return render(request,'complaint/viewcomplaint.html',context)
def viewreply(request):
    objlist = Complaint.objects.filter(u_id=request.session["user"])
    context = {
        'objval': objlist,
    }
    return render(request,'complaint/view_reply.html',context)
