from  django.conf.urls import url
from complaint import views
urlpatterns = [
    url('^$',views.complaint,name='complaint'),
   url(r'^replycomplaint/(?P<idd>\w+)',views.replycomplaint,name='replycomplaint'),
    url('^viewcomplaint/',views.viewcomplaint,name='viewcomplaint'),
    url('^viewreply/',views.viewreply,name='viewreply'),

]