from django.shortcuts import render
from chitdetails.models import Chitdetails
from request.models import Request
import datetime
from django.db import connection

def viewrequest(request):
    objlist = connection.cursor()
    objlist.execute("SELECT * FROM chitdetails a,request b,registration c WHERE a.c_id=b.c_id and b.u_id=c.u_id")

    context = {
        'objval': objlist.fetchall(),
    }

    return render(request,'request/view request.html',context)
def raccept(request,idd):

        obj = Request.objects.get(r_id=idd)
        obj.status = "approve"

        obj.save()
        return viewrequest(request)
def rreject(request,idd):
    obj = Request.objects.get(r_id=idd)
    obj.status = "reject"

    obj.save()

    return viewrequest(request)
