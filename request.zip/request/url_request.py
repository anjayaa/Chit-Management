from  django.conf.urls import url
from request import views
urlpatterns = [
   url('^$',views.viewrequest,name='viewrequest'),
   url('^raccept/(?P<idd>\w+)', views.raccept, name='raccept'),
   url('^rreject/(?P<idd>\w+)', views.rreject, name='rreject'),

]
