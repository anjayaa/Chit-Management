from django.shortcuts import render
from notification.models import Notification
from chitdetails.models import Chitdetails
from request.models import Request
from django.db import connection
# Create your views here.
def addnoti(request):
    objlist = Chitdetails.objects.all()
    context = {
        'objval': objlist,
    }
    if request.method == "POST":
        obj = Notification()
        obj.description = request.POST.get("Add")
        obj.date = request.POST.get("date")
        obj.cid = request.POST.get("cid")
        obj.save()
    return render(request,'notification/add noti.html',context)
# def duenoti(request):
#     return render(request,'notification/duenoti.html')
# def duesnoti(request):
#     return render(request,'notification/duesnoti.html')
# def winusers(request):
#     return render(request,'notification/postnotiwinuser.html')
def viewnoti(request):
    # uid = request.session["user"]
    # objlist1 = Request.objects.get(u_id=uid)
    # cid=objlist1.c_id
    #
    # objlist = Notification.objects.filter(cid=cid)
    # context = {
    #     'objval': objlist,
    # }

    uid = request.session["user"]

    objlist = connection.cursor()
    uidd = str(uid)
    query = (
        "SELECT * FROM notification a,request b,chitdetails c WHERE a.cid = b.c_id AND b.u_id = %s AND a.cid=c.c_id ")
    objlist.execute(query, [uid])
    # print(uid)
    # print(uidd)

    context = {
        'objval': objlist.fetchall(),

    }
    return render(request,'notification/view noti.html',context)

