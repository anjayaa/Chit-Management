from  django.conf.urls import url
from  notification import views
urlpatterns = [
    url('^$',views.addnoti,name='addnoti'),
   #  url('^duenoti/', views.winusers, name='duenoti'),
   # url('^duesnoti/',views.duesnoti,name='duesnoti'),
   #  url('^winusers/', views.winusers, name='winusers'),
    url('^viewnoti/', views.viewnoti, name='viewnoti'),

]
