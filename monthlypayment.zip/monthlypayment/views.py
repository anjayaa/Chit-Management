from django.shortcuts import render
from chitdetails.models import Chitdetails
from monthlypayment.models import Monthlypayment
from request.models import Request
import datetime
# Create your views here.
def monthlypayment(request):
    objlist = Request.objects.filter(status='approve')
    cid=objlist.c_id
    objlist1=Chitdetails.objects.filter(c_id=cid)
    amot=objlist1.monthly_pay_amount
    obj = Chitdetails.objects.filter(c_id=cid)
    for o in obj:
        p = Monthlypayment()
        p.amount = o.monthly_pay_amount
        p.u_id = request.data["accno"]
        p.paymentdate = datetime.date.today()
        p.status = "payed"
        p.chit_id =o.c_id
        p.save()
    return render(request, 'monthlypayment/view_chiti.html',)
def monthlypay(request):
        objlist = Chitdetails.objects.all()
        context = {
            'objval': objlist,
        }
        return render(request,'monthlypayment/view_chiti.html',context)

def monthlypaydtails(request,idd):
    objlist = Monthlypayment.objects.filter(chit_id=idd,status='pay')
    context = {
        'objval': objlist,
    }
    return render(request, 'monthlypayment/monthlypayment.html', context)
def monthlynoti(request,idd):
    if request.method == "POST":
        obj=Request.objects.filter(c_id=idd)
        for o in obj:
            a=Monthlypayment()
            a.u_id=o.u_id
            a.amount=request.POST.get("amount")
            a.paymentdate=request.POST.get("date")
            a.status="pending"
            a.chit_id=idd
            a.save()
            return monthlypay(request)

    return render(request, 'monthlypayment/paymentnotifications.html')