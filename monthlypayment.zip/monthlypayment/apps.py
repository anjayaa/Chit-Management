from django.apps import AppConfig


class MonthlypaymentConfig(AppConfig):
    name = 'monthlypayment'
