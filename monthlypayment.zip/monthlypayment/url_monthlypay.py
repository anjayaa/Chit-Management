from  django.conf.urls import url
from monthlypayment import views
urlpatterns = [
    url('^$',views.monthlypay,name='monthlypayment'),
    url('^monthlypayment/', views.monthlypayment, name='monthlypayment'),
    url('^monthlypaydtails/(?P<idd>\w+)', views.monthlypaydtails, name='monthlypaydtails'),
    url('^monthlynoti/(?P<idd>\w+)', views.monthlynoti, name='monthlynoti'),
]