from django.shortcuts import render
from django.http import HttpResponse
from login.models import Login
# Create your views here.
def login(request):
        if request.method == "POST":
            uname = request.POST.get("username")
            passw = request.POST.get("pass")

            obj = Login.objects.filter(username=uname, password=passw)
            tp = ""
            for ob in obj:
                tp = ob.type
                u_id = ob.uid
                if tp == "user":
                    request.session["user"]= u_id

                    return render(request,'login/userhome.html')

                elif tp == "admin":
                    request.session["admin"] = u_id

                    return render(request,'login/chitmanagerhome.html')


                elif tp == "fadmin":
                    request.session["fadmin"] = u_id

                    return render(request,'login/agenthome.html')



                else:
                    return render(request, 'login/login.html')

        return render(request, 'login/login.html')
        # return HttpResponse("login")
